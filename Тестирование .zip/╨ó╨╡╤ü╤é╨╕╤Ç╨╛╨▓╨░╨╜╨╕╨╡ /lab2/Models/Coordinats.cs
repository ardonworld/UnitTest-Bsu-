using System;
using System.Collections;

namespace lab2.Models
{
    public class Coordinats
    {
        public double x { get; set; }
        public double y { get; set; }
    }
}