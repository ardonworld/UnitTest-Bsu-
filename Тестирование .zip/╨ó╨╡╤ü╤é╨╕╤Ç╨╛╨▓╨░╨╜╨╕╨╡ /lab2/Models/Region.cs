using System;
using System.Collections;

namespace lab2.Models
{
    public class Region
    {
        public Coordinats Coordinats { get; set; }
        public string Value { get; set; }
    }
}