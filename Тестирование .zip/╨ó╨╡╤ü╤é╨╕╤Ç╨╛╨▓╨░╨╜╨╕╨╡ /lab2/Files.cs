using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using lab2.Models;

namespace lab2
{
    public class Files
    {
        public List<Coordinats> Coordinats { get; set; }
        public string InPath { get; set; }
        public string OutPath { get; set; }
        public Files(string inPath, string outPath)
        {
            this.InPath = inPath;
            this.OutPath = outPath;
        }

        public List<Coordinats> fillCoordinats()
        {
            try
            {
                using (var sr = new StreamReader(InPath))
                {
                    var newCoordinats = new List<Coordinats>();
                    while (!sr.EndOfStream)
                    {
                        string dryCoordinats = sr.ReadLine();

                        var coordinats = dryCoordinats.Split(' ');

                        newCoordinats.Add(new Coordinats
                        {
                            x = Convert.ToDouble(coordinats[0]),
                            y = Convert.ToDouble(coordinats[1])
                        });

                    }
                    return newCoordinats;
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
                throw;
            }
        }

        public void printRegions(IEnumerable<Region> regions)
        {
            try
            {
                using (var sr = new StreamWriter(OutPath))
                {
                    foreach (var region in regions)
                        sr.WriteLine($"x,y = ({region.Coordinats.x}; {region.Coordinats.y};) {region.Value}");
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("The file could not be write:");
                Console.WriteLine(e.Message);
            }
        }

        public IEnumerable<Region> GetRegions()
        {
            var Regions = new List<Region>();

            foreach (var coordinats in Coordinats)
                Regions.Add(MathRegion.CalculateRegion(coordinats));

            return Regions;
        }
    }
}