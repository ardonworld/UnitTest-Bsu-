using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using lab2.Models;

namespace lab2
{
    public static class MathRegion
    {
        public static Region CalculateRegion(Coordinats coordinats)
        {

            if ((coordinats.x >1.57 && coordinats.x < Math.PI) && (coordinats.y >= 0 && coordinats.y<=Math.Sin(coordinats.x)))
                return new Region { Coordinats = coordinats, Value = "Область: F" };

            if ((coordinats.y >= 0 && coordinats.y <= Math.Sin(coordinats.x)) && ((coordinats.x>=-2*Math.PI) && (coordinats.x <-1* Math.PI )))
                return new Region { Coordinats = coordinats, Value = "Область: A" };   

            if ((coordinats.x >(-1 * Math.PI) && coordinats.x <0) && (coordinats.y > 0 ))
                return new Region { Coordinats = coordinats, Value = "Область: B" };     

            if ((coordinats.x <0 && coordinats.x >= -1 * Math.PI) && ((coordinats.y >= Math.Sin(coordinats.x)) && coordinats.y <=0))
                return new Region { Coordinats = coordinats, Value = "Область: C" }; 

            if (coordinats.x>0 && coordinats.y < 0 )         
                return new Region { Coordinats = coordinats, Value = "Область: D" };

            if ((coordinats.x >=0 && coordinats.x <=1.57) && (coordinats.y >= 0 && coordinats.y <= Math.Sin(coordinats.x)))
                return new Region { Coordinats = coordinats, Value = "Область: E" };
                
            return new Region { Coordinats = coordinats, Value = "Область не определена" };
        }
    }
}