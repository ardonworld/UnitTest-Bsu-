﻿using System;
using System.IO;
using lab2.Models;
using System.Collections;
using System.Collections.Generic;


namespace lab2
{
    class Program
    {
        private static readonly IEnumerable<string> line;

        static void Main(string[] args)
        {
            Console.Write("Путь входной файл: ");
            var inPath = Console.ReadLine();
            
            Console.Write("Путь выходной файл: ");
            var outPath = Console.ReadLine();

            var file = new Files(inPath, outPath);

            file.Coordinats = file.fillCoordinats();

            var regions = file.GetRegions();

            file.printRegions(regions);
            Console.WriteLine("Данные выведены в файл");
        }
    }
}

